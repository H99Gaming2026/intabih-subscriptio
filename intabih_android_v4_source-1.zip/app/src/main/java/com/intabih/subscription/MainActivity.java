package com.intabih.subscription;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.*;
import android.widget.Toast;
import androidx.annotation.Nullable;

import org.json.JSONObject;
import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44);
        }
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        web.setBackgroundColor(0xFF0B1220);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    public static class AndroidBridge {
        private final Context context;
        AndroidBridge(Context c) { context = c.getApplicationContext(); }

        @JavascriptInterface public void scheduleSubscription(String json) {
            try {
                JSONObject s = new JSONObject(json);
                String id = s.getString("id"), name = s.getString("name"), date = s.getString("date");
                String[] p = date.split("-");
                Calendar target = Calendar.getInstance();
                target.set(Integer.parseInt(p[0]), Integer.parseInt(p[1])-1, Integer.parseInt(p[2]), 9, 0, 0);
                target.set(Calendar.MILLISECOND, 0);
                long end = target.getTimeInMillis();
                int[] offsets = {3,1,0};
                for (int days : offsets) {
                    long when = end - days * 24L * 60L * 60L * 1000L;
                    if (when <= System.currentTimeMillis()) continue;
                    Intent intent = new Intent(context, ReminderReceiver.class);
                    intent.putExtra("name", name);
                    intent.putExtra("days", days);
                    intent.putExtra("id", id);
                    int request = (id + "_" + days).hashCode() & 0x7fffffff;
                    PendingIntent pi = PendingIntent.getBroadcast(context, request, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
                    if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                }
            } catch (Exception e) { }
        }

        @JavascriptInterface public void cancelSubscription(String id) {
            int[] offsets = {3,1,0};
            AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
            for (int days : offsets) {
                Intent intent = new Intent(context, ReminderReceiver.class);
                int request = (id + "_" + days).hashCode() & 0x7fffffff;
                PendingIntent pi = PendingIntent.getBroadcast(context, request, intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) { if (am != null) am.cancel(pi); pi.cancel(); }
            }
        }
    }
}
